package dm.badlogic.androidgames.mrnom;

import android.util.Log;
import dm.badlogic.androidgames.framework.Screen;
import dm.badlogic.androidgames.framework.impl.AndroidGame;


public class MrNomGame extends AndroidGame {

	@Override
	public Screen getStartScreen() {
		Log.e("Craig Log", "Entered MrNomGame");
		// TODO Auto-generated method stub
		return new LoadingScreen(this);
	}
}
