/** Automatically generated file. DO NOT MODIFY */
package dm.badlogic.androidgames.mrnom;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}