/** Automatically generated file. DO NOT MODIFY */
package dm.badlogic.androidgames.framework.impl;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}